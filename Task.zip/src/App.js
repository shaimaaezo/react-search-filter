import Task from './component/task.jsx'

function App() {
  return (
    <Task/>
  );
}

export default App;
